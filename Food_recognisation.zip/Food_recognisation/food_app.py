import os
import numpy as np
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras.preprocessing import image
import streamlit as st

# Warnings off
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'

# Load model
model = keras.models.load_model("C:/Users/priya/food_model.h5", compile=False)

# Class names
class_names = ["Chole_Bhature", "Pizza"]

# Nutrition data
nutrition_info = {
    "Chole_Bhature": {
        "Calories": "450 kcal",
        "Protein": "12g",
        "Carbs": "50g",
        "Fat": "20g",
        "Alternative": "Try steamed idli or chapati with chole instead of fried bhature"
    },
    "Pizza": {
        "Calories": "300 kcal",
        "Protein": "15g",
        "Carbs": "40g",
        "Fat": "12g",
        "Alternative": "Opt for thin-crust veggie pizza with less cheese"
    }
}

# Prediction function
def predict_food(img):
    img = img.resize((128, 128))
    img_array = np.array(img)
    img_array = np.expand_dims(img_array, axis=0) / 255.0

    preds = model.predict(img_array)
    score = tf.nn.softmax(preds[0])
    class_index = np.argmax(score)
    return class_names[class_index], float(np.max(score))

# Streamlit UI
st.title("🍽 Food Recognition & Nutrition Estimator")
st.write("Upload an image of food, and I'll predict the category and suggest nutrition info + healthier alternatives!")

uploaded_file = st.file_uploader("Upload a food image", type=["jpg", "jpeg", "png"])

if uploaded_file is not None:
    from PIL import Image
    img = Image.open(uploaded_file)

    # Show image
    st.image(img, caption="Uploaded Image", use_container_width=True)

    # Prediction
    label, confidence = predict_food(img)

    st.subheader(f"🍴 Prediction: **{label}** ({confidence*100:.2f}%)")

    st.subheader("📊 Nutrition Info")
    nutri = nutrition_info[label]
    st.write(f"- **Calories**: {nutri['Calories']}")
    st.write(f"- **Protein**: {nutri['Protein']}")
    st.write(f"- **Carbs**: {nutri['Carbs']}")
    st.write(f"- **Fat**: {nutri['Fat']}")

    st.subheader("🌱 Healthier Alternative")
    st.write(nutri["Alternative"])
